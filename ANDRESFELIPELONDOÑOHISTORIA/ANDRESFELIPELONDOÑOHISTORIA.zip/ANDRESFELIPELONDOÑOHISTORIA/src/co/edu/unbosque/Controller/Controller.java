package co.edu.unbosque.Controller;
import co.edu.unbosque.Model.Habitantes;
import co.edu.unbosque.View.View;

public class Controller {

	private Habitantes h;
	private View v;
	
	public Controller(){
		
		h = new Habitantes();
		v = new View();
		
		funcionar();
}
	
	public void funcionar() {
		v.mostrarResultados(h.getAndres().getColorOjos());
		
	}
}

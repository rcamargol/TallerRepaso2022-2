package co.edu.unbosque.Model;

public class Heroes extends KublaKan{

	int estatura = 3; 
	
	
	String volar() {
		return "Vuelo para proteger el planeta";
	}
	
	String crearFuego() {
		return "Creo fuego para proteger el planeta";
	}
	
	String detenerTiempo() {
		return "Este poder es imparable";
	}
	
	@Override
	String habitar() {
		return "Vivo en el norte del planeta";
		
		
	}

	@Override
	String sentir() {
		return "Puedo sentirme a mi y a seres de otros mundos";
		
		
	}

	public int getEstatura() {
		return estatura;
	}

	public void setEstatura(int estatura) {
		this.estatura = estatura;
	}

}

package co.edu.unbosque.Model;

public class Desterrados extends KublaKan {

	boolean alma = false;
	int edad = 1500;
	
	String arrastrarse() {
		return "Me arrastro de un lugar a otro";
	}
	
	@Override
	String habitar() {
		return "Habito el sur del planeta";
		
		
	}

	@Override
	String sentir() {
		return "Solo me puedo sentir a mi mismo";
		
		
	}

	public boolean isAlma() {
		return alma;
	}

	public void setAlma(boolean alma) {
		this.alma = alma;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

}

package co.edu.unbosque.Model;

public class Mortales extends KublaKan{

	String colorOjos = "violeta";
	
	
	
	
	
	String adquirirConocimiento() {
		return "He adquirido mucho conocimiento";
		
	}
	String tenerFamilia() {
		return "Tengo una familia faliz :)";
		
	}
	String ejercerProfesion() {
		return "Tengo trabajo que hacer";
		
	}
	
	@Override
	String habitar() {
		return "Habito en el este del planeta";
		
	}
	@Override
	String sentir() {
		return "Siento la presencia de otros mortales";
		
		
	}
	public String getColorOjos() {
		return colorOjos;
	}
	public void setColorOjos(String colorOjos) {
		this.colorOjos = colorOjos;
	}

}

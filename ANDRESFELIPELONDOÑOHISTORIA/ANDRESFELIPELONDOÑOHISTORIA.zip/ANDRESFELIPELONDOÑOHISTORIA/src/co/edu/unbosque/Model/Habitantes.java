package co.edu.unbosque.Model;

public class Habitantes {

	Desterrados Renk;
	Mortales Andres;
	Heroes Kira, Astar;
	
	public void habitantes() {
		Renk = new Desterrados();
		Andres = new Mortales();
		Kira = new Heroes();
		Astar = new Heroes();
	}

	public Desterrados getRenk() {
		return Renk;
	}

	public void setRenk(Desterrados renk) {
		Renk = renk;
	}

	public Mortales getAndres() {
		return Andres;
	}

	public void setAndres(Mortales andres) {
		Andres = andres;
	}

	public Heroes getKira() {
		return Kira;
	}

	public void setKira(Heroes kira) {
		Kira = kira;
	}

	public Heroes getAstar() {
		return Astar;
	}

	public void setAstar(Heroes astar) {
		Astar = astar;
	}
	
	

}

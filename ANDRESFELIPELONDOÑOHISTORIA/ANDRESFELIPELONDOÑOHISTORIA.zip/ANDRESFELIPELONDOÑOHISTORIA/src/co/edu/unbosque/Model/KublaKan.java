package co.edu.unbosque.Model;

public abstract class KublaKan {

	protected String colorOjos;
	protected int edad;
	protected int estatura;
	protected boolean alma;
	
	abstract String habitar();
	abstract String sentir();
}